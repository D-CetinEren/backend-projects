package main

import "github.com/D-CetinEren/backend-projects/go/expense-tracker/cmd"

func main() {
	cmd.Execute()
}
